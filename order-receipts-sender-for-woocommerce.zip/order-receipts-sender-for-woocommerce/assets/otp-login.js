/* Order Receipt Messenger — OTP Login JS */
(function ($) {
    'use strict';

    var cfg = window.ormOtp || {};

    function sendOtp( identifierField, codeWrap, msgEl, btnEl ) {
        var identifier = $( identifierField ).val().trim();
        if ( ! identifier ) {
            $( msgEl ).css('color','#c00').text('Please enter your phone number or Chat ID.');
            return;
        }
        var origText = $( btnEl ).text();
        $( btnEl ).prop('disabled', true).text('Sending…');
        $( msgEl ).css('color','').text('');

        $.ajax({
            url:  cfg.ajax_url,
            type: 'POST',
            data: {
                action:     'orm_request_otp',
                nonce:      cfg.nonce,
                identifier: identifier
            },
            success: function (res) {
                if ( res.success ) {
                    $( codeWrap ).slideDown(200);
                    $( msgEl ).css('color','green').text('✅ ' + res.data);
                    $( codeWrap ).find('input').focus();
                } else {
                    $( msgEl ).css('color','#c00').text('❌ ' + res.data);
                }
            },
            error: function () {
                $( msgEl ).css('color','#c00').text('❌ Network error. Please try again.');
            },
            complete: function () {
                $( btnEl ).prop('disabled', false).text( origText );
            },
        });
    }

    $(document).ready(function () {

        // ── Login form (WP native + WooCommerce My Account) ──────
        $(document).on('click', '#orm-send-otp', function (e) {
            e.preventDefault();
            // Support both WP login (#orm_otp_phone) and WC login (#orm_otp_phone_wc)
            var phoneField = $('#orm_otp_phone_wc').length ? '#orm_otp_phone_wc' : '#orm_otp_phone';
            sendOtp( phoneField, '#orm-otp-code-wrap', '#orm-otp-msg', '#orm-send-otp' );
        });

        // ── Registration form ─────────────────────────────────────
        $(document).on('click', '#orm-reg-send-otp', function (e) {
            e.preventDefault();
            sendOtp( '#orm_reg_otp_phone', '#orm-reg-otp-code-wrap', '#orm-reg-otp-msg', '#orm-reg-send-otp' );
        });

        // ── Visual feedback as user types OTP ─────────────────────
        $(document).on('input', '#orm_otp_code, #orm_reg_otp_code', function () {
            $(this).css('border-color', $(this).val().length === 6 ? 'green' : '' );
        });
    });

}(jQuery));
