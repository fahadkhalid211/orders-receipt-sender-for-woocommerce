/* Order Receipt Messenger v2 — Admin JS */
(function ($) {
    'use strict';

    var cfg = window.ormReceipt || {};

    // Provider rows to show/hide based on WA provider selection
    var WA_PROVIDERS  = { ultramsg: '.orm-field-ultramsg', whatsapp_business: '.orm-field-waba', callmebot: '.orm-field-callmebot', twilio_wa: '.orm-field-twilio', twilio_sms: '.orm-field-twilio' };
    var SMS_PROVIDERS = { textbelt: '.orm-field-textbelt', twilio_sms: '.orm-field-twilio' };

    function toggleProviderFields() {
        var waProv  = $('#orm_whatsapp_provider').val();
        var smsProv = $('#orm_sms_provider').val();

        // Hide all credential rows first
        $('.orm-field-ultramsg, .orm-field-waba, .orm-field-callmebot, .orm-field-textbelt').closest('tr').hide();
        // Twilio is shared — show if either WA or SMS uses it
        var showTwilio = ( waProv === 'twilio_wa' || smsProv === 'twilio_sms' );
        $('.orm-field-twilio').closest('tr').toggle( showTwilio );

        // Show rows for selected WA provider
        if ( WA_PROVIDERS[ waProv ] && waProv !== 'twilio_wa' ) {
            $( WA_PROVIDERS[ waProv ] ).closest('tr').show();
        }
        // Show rows for selected SMS provider
        if ( SMS_PROVIDERS[ smsProv ] && smsProv !== 'twilio_sms' ) {
            $( SMS_PROVIDERS[ smsProv ] ).closest('tr').show();
        }
    }

    function toggleSectionVisibility() {
        // Show/hide full credential sections based on channel checkboxes
        var waActive   = $('input[name="orm_channels[]"][value="whatsapp"]').is(':checked');
        var tgActive   = $('input[name="orm_channels[]"][value="telegram"]').is(':checked');
        var smsActive  = $('input[name="orm_channels[]"][value="sms"]').is(':checked');

        // WA provider dropdown row
        $('select#orm_whatsapp_provider').closest('tr').toggle( waActive );
        // Telegram section rows
        $('.orm-field-telegram').closest('tr').toggle( tgActive );
        // SMS provider dropdown row
        $('select#orm_sms_provider').closest('tr').toggle( smsActive );

        toggleProviderFields();
    }

    $(document).ready(function () {

        toggleSectionVisibility();

        $('input[name="orm_channels[]"]').on( 'change', toggleSectionVisibility );
        $('select#orm_whatsapp_provider, select#orm_sms_provider').on( 'change', toggleProviderFields );

        // ── Per-channel test send ─────────────────────────────────
        $(document).on( 'click', '#orm-send-test', function (e) {
            e.preventDefault();
            var $btn      = $(this);
            var $result   = $('#orm-test-result');
            var channel   = $('#orm-test-channel').val();
            var recipient = $('#orm-test-recipient').val().trim();

            if ( ! recipient ) {
                $result.removeClass('orm-success').addClass('orm-error')
                    .text( '❌ Please enter a ' + ( channel === 'telegram' ? 'Chat ID' : 'phone number' ) + '.' );
                return;
            }

            $btn.prop('disabled', true).text('Sending…');
            $result.removeClass('orm-success orm-error').text('');

            $.ajax({
                url:  cfg.ajax_url,
                type: 'POST',
                data: { action: 'orm_send_test', nonce: cfg.nonce, channel: channel, recipient: recipient },
                success: function (res) {
                    if ( res.success ) {
                        $result.removeClass('orm-error').addClass('orm-success').text( '✅ ' + res.data );
                    } else {
                        $result.removeClass('orm-success').addClass('orm-error').text( '❌ ' + res.data );
                    }
                },
                error: function () {
                    $result.removeClass('orm-success').addClass('orm-error').text('❌ Network error.');
                },
                complete: function () { $btn.prop('disabled', false).text('Send Test'); },
            });
        });
    });

}(jQuery));
