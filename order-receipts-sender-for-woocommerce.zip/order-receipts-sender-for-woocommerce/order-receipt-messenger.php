<?php
/**
 * Plugin Name: Order Receipts Sender for WooCommerce
 * Plugin URI:  https://github.com/fahadkhalid211/
 * Description: Send WooCommerce order receipts via WhatsApp, Telegram and SMS simultaneously. Includes Login/Register OTP verification for all three channels.
 * Version:     2.1.0
 * Author:      Fahad Khalid
 * Author URI:  https://linktr.ee/fahadkhalid211
 * License:     GPL-2.0+
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: order-receipts-sender-for-woocommerce
 * Domain Path: /languages
 * Requires at least: 5.8
 * Tested up to: 6.9
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'ORM_VERSION',    '2.1.0' );
define( 'ORM_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'ORM_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'ORM_TEXT_DOMAIN', 'order-receipts-sender-for-woocommerce' );

// ─────────────────────────────────────────────
// AUTOLOAD INCLUDES (always, so activation hook can use classes)
// ─────────────────────────────────────────────
require_once ORM_PLUGIN_DIR . 'includes/class-orm-sender.php';
require_once ORM_PLUGIN_DIR . 'includes/class-orm-settings.php';
require_once ORM_PLUGIN_DIR . 'includes/class-orm-hooks.php';
require_once ORM_PLUGIN_DIR . 'includes/class-orm-checkout-field.php';
require_once ORM_PLUGIN_DIR . 'includes/class-orm-otp.php';

// ─────────────────────────────────────────────
// BOOTSTRAP — init only after WooCommerce is loaded
// ─────────────────────────────────────────────
add_action( 'plugins_loaded', 'order_receipt_messenger_init' );

/**
 * Initialise the plugin after all plugins are loaded.
 */
function order_receipt_messenger_init() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', function () {
            echo '<div class="error"><p><strong>Order Receipt Messenger</strong> requires WooCommerce to be installed and active.</p></div>';
        } );
        return;
    }

    ORM_Settings::init();
    ORM_Hooks::init();
    ORM_Checkout_Field::init();
    ORM_OTP::init();
}

// ─────────────────────────────────────────────
// ACTIVATION / DEACTIVATION
// ─────────────────────────────────────────────
register_activation_hook( __FILE__, 'order_receipt_messenger_activate' );

/**
 * Set default plugin options on activation.
 * Classes are already loaded at file level above, so ORM_OTP is available here.
 */
function order_receipt_messenger_activate() {
    if ( ! get_option( 'orm_channels' ) ) {
        update_option( 'orm_channels', array( 'telegram' ) );
    }
    if ( ! get_option( 'orm_trigger_status' ) ) {
        update_option( 'orm_trigger_status', 'processing' );
    }
    if ( ! get_option( 'orm_message_template' ) ) {
        update_option( 'orm_message_template', order_receipt_messenger_default_template() );
    }
    if ( ! get_option( 'orm_sms_template' ) ) {
        update_option( 'orm_sms_template', order_receipt_messenger_default_sms_template() );
    }

    // Create OTP table — class is now available because files are loaded above
    ORM_OTP::create_table();
}

register_deactivation_hook( __FILE__, 'order_receipt_messenger_deactivate' );

/**
 * Clean up on deactivation.
 */
function order_receipt_messenger_deactivate() {
    wp_clear_scheduled_hook( 'orm_cleanup_otps' );
}

/**
 * Default rich message template (WhatsApp / Telegram).
 *
 * @return string
 */
function order_receipt_messenger_default_template() {
    return "Hello {customer_name}! \xF0\x9F\x9B\x8D\xEF\xB8\x8F\n\nThank you for your order at {site_name}.\n\n\xF0\x9F\x93\xA6 *Order #{order_number}*\nDate: {order_date}\nStatus: {order_status}\n\n\xF0\x9F\x9B\x92 *Items Ordered:*\n{order_items}\n\n\xF0\x9F\x92\xB0 *Order Total: {order_total}*\n\nWe will notify you once your order is shipped.\n\n\xF0\x9F\x94\x97 Track your order: {order_url}\n\nThank you for shopping with us!";
}

/**
 * Default SMS template (plain text, keep short).
 *
 * @return string
 */
function order_receipt_messenger_default_sms_template() {
    return "{site_name}: Hi {customer_name}, your order #{order_number} ({order_total}) is {order_status}. Track: {order_url}";
}
