<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * ORM_Sender — dispatches a message through a specific channel/provider.
 *
 * Channels:
 *   whatsapp  → UltraMsg | WhatsApp Business API | CallMeBot | Twilio (WhatsApp)
 *   telegram  → Telegram Bot API
 *   sms       → Twilio SMS | TextBelt (free)
 */
class ORM_Sender {

    /**
     * Send a message on a specific channel.
     *
     * @param string $channel    'whatsapp' | 'telegram' | 'sms'
     * @param string $recipient  Phone (E.164) or Telegram Chat ID
     * @param string $message    Message body (* = bold)
     * @return true|WP_Error
     */
    public function send( string $channel, string $recipient, string $message ) {
        switch ( $channel ) {
            case 'telegram':
                return $this->via_telegram( trim( $recipient ), $message );
            case 'sms':
                return $this->via_sms( $this->normalise_phone( $recipient ), $message );
            case 'whatsapp':
            default:
                return $this->via_whatsapp( $this->normalise_phone( $recipient ), $message );
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private function normalise_phone( string $phone ): string {
        $phone = preg_replace( '/[\s\-\(\)]/', '', $phone );
        if ( substr( $phone, 0, 1 ) !== '+' ) {
            $phone = '+' . $phone;
        }
        return $phone;
    }

    private function to_telegram_html( string $text ): string {
        return preg_replace( '/\*(.*?)\*/', '<b>$1</b>', $text );
    }

    private function strip_markdown( string $text ): string {
        return preg_replace( '/\*(.*?)\*/', '$1', $text );
    }

    // ── WhatsApp dispatcher ───────────────────────────────────────────────────

    private function via_whatsapp( string $phone, string $message ) {
        $provider = get_option( 'orm_whatsapp_provider', 'ultramsg' );
        switch ( $provider ) {
            case 'whatsapp_business':
                return $this->wa_business( $phone, $message );
            case 'callmebot':
                return $this->wa_callmebot( $phone, $message );
            case 'twilio_wa':
                return $this->wa_twilio( $phone, $message );
            case 'ultramsg':
            default:
                return $this->wa_ultramsg( $phone, $message );
        }
    }

    // ── WhatsApp: UltraMsg ────────────────────────────────────────────────────
    private function wa_ultramsg( string $phone, string $message ) {
        $instance = get_option( 'orm_ultramsg_instance', '' );
        $token    = get_option( 'orm_ultramsg_token', '' );
        if ( empty( $instance ) || empty( $token ) ) {
            return new WP_Error( 'missing_config', 'UltraMsg: Instance ID or Token not configured.' );
        }
        $response = wp_remote_post(
            'https://api.ultramsg.com/' . rawurlencode( $instance ) . '/messages/chat',
            array(
                'timeout' => 15,
                'headers' => array( 'Content-Type' => 'application/x-www-form-urlencoded' ),
                'body'    => http_build_query( array( 'token' => $token, 'to' => $phone, 'body' => $message ) ),
            )
        );
        return $this->handle_response( $response, 'UltraMsg' );
    }

    // ── WhatsApp: Meta Business API ───────────────────────────────────────────
    private function wa_business( string $phone, string $message ) {
        $phone_id = get_option( 'orm_waba_phone_number_id', '' );
        $token    = get_option( 'orm_waba_access_token', '' );
        if ( empty( $phone_id ) || empty( $token ) ) {
            return new WP_Error( 'missing_config', 'WhatsApp Business API: Phone Number ID or Access Token not configured.' );
        }
        $response = wp_remote_post(
            'https://graph.facebook.com/v19.0/' . rawurlencode( $phone_id ) . '/messages',
            array(
                'timeout' => 15,
                'headers' => array( 'Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json' ),
                'body'    => wp_json_encode( array(
                    'messaging_product' => 'whatsapp',
                    'to'   => ltrim( $phone, '+' ),
                    'type' => 'text',
                    'text' => array( 'body' => $message ),
                ) ),
            )
        );
        return $this->handle_response( $response, 'WhatsApp Business API' );
    }

    // ── WhatsApp: CallMeBot ───────────────────────────────────────────────────
    private function wa_callmebot( string $phone, string $message ) {
        $apikey = get_option( 'orm_callmebot_apikey', '' );
        if ( empty( $apikey ) ) {
            return new WP_Error( 'missing_config', 'CallMeBot: API key not configured.' );
        }
        $response = wp_remote_get(
            add_query_arg( array(
                'phone'  => rawurlencode( $phone ),
                'text'   => rawurlencode( $message ),
                'apikey' => rawurlencode( $apikey ),
            ), 'https://api.callmebot.com/whatsapp.php' ),
            array( 'timeout' => 15 )
        );
        return $this->handle_response( $response, 'CallMeBot' );
    }

    // ── WhatsApp: Twilio ──────────────────────────────────────────────────────
    private function wa_twilio( string $phone, string $message ) {
        $sid   = get_option( 'orm_twilio_sid', '' );
        $token = get_option( 'orm_twilio_token', '' );
        $from  = get_option( 'orm_twilio_wa_from', '' );
        if ( empty( $sid ) || empty( $token ) || empty( $from ) ) {
            return new WP_Error( 'missing_config', 'Twilio WhatsApp: Credentials not fully configured.' );
        }
        $response = wp_remote_post(
            'https://api.twilio.com/2010-04-01/Accounts/' . $sid . '/Messages.json',
            array(
                'timeout' => 15,
                'headers' => array(
                    'Authorization' => 'Basic ' . base64_encode( $sid . ':' . $token ),
                    'Content-Type'  => 'application/x-www-form-urlencoded',
                ),
                'body' => http_build_query( array(
                    'From' => 'whatsapp:' . $from,
                    'To'   => 'whatsapp:' . $phone,
                    'Body' => $message,
                ) ),
            )
        );
        return $this->handle_response( $response, 'Twilio WhatsApp' );
    }

    // ── Telegram ──────────────────────────────────────────────────────────────
    private function via_telegram( string $chat_id, string $message ) {
        $token = get_option( 'orm_telegram_bot_token', '' );
        if ( empty( $token ) ) {
            return new WP_Error( 'missing_config', 'Telegram: Bot Token not configured.' );
        }
        if ( empty( $chat_id ) ) {
            return new WP_Error( 'missing_config', 'Telegram: Chat ID is missing.' );
        }
        $response = wp_remote_post(
            'https://api.telegram.org/bot' . rawurlencode( $token ) . '/sendMessage',
            array(
                'timeout' => 15,
                'body'    => array(
                    'chat_id'    => $chat_id,
                    'text'       => $this->to_telegram_html( $message ),
                    'parse_mode' => 'HTML',
                ),
            )
        );
        return $this->handle_response( $response, 'Telegram' );
    }

    // ── SMS dispatcher ────────────────────────────────────────────────────────
    private function via_sms( string $phone, string $message ) {
        $provider = get_option( 'orm_sms_provider', 'textbelt' );
        $plain    = $this->strip_markdown( $message );
        switch ( $provider ) {
            case 'twilio_sms':
                return $this->sms_twilio( $phone, $plain );
            case 'textbelt':
            default:
                return $this->sms_textbelt( $phone, $plain );
        }
    }

    // ── SMS: TextBelt (1 free SMS/day per IP, paid for more) ─────────────────
    private function sms_textbelt( string $phone, string $message ) {
        $api_key = get_option( 'orm_textbelt_key', 'textbelt' ); // 'textbelt' = free tier
        $response = wp_remote_post(
            'https://textbelt.com/text',
            array(
                'timeout' => 15,
                'body'    => array(
                    'phone'   => $phone,
                    'message' => $message,
                    'key'     => $api_key,
                ),
            )
        );
        if ( is_wp_error( $response ) ) {
            return new WP_Error( 'http_error', 'TextBelt: ' . $response->get_error_message() );
        }
        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( ! empty( $body['success'] ) ) {
            return true;
        }
        $err = ! empty( $body['error'] ) ? $body['error'] : 'Unknown error';
        return new WP_Error( 'api_error', 'TextBelt: ' . $err );
    }

    // ── SMS: Twilio SMS ───────────────────────────────────────────────────────
    private function sms_twilio( string $phone, string $message ) {
        $sid   = get_option( 'orm_twilio_sid', '' );
        $token = get_option( 'orm_twilio_token', '' );
        $from  = get_option( 'orm_twilio_sms_from', '' );
        if ( empty( $sid ) || empty( $token ) || empty( $from ) ) {
            return new WP_Error( 'missing_config', 'Twilio SMS: Credentials not fully configured.' );
        }
        $response = wp_remote_post(
            'https://api.twilio.com/2010-04-01/Accounts/' . $sid . '/Messages.json',
            array(
                'timeout' => 15,
                'headers' => array(
                    'Authorization' => 'Basic ' . base64_encode( $sid . ':' . $token ),
                    'Content-Type'  => 'application/x-www-form-urlencoded',
                ),
                'body' => http_build_query( array(
                    'From' => $from,
                    'To'   => $phone,
                    'Body' => $message,
                ) ),
            )
        );
        return $this->handle_response( $response, 'Twilio SMS' );
    }

    // ── Shared HTTP response handler ──────────────────────────────────────────
    private function handle_response( $response, string $label ) {
        if ( is_wp_error( $response ) ) {
            return new WP_Error( 'http_error', $label . ' request failed: ' . $response->get_error_message() );
        }
        $code = (int) wp_remote_retrieve_response_code( $response );
        if ( $code >= 200 && $code < 300 ) {
            return true;
        }
        return new WP_Error( 'api_error', sprintf( '%s API error (HTTP %d): %s', $label, $code, wp_remote_retrieve_body( $response ) ) );
    }
}
