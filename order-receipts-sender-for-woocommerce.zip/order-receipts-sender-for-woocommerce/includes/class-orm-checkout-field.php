<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Adds optional phone and Telegram Chat ID fields to checkout.
 */
class ORM_Checkout_Field {

    public static function init() {
        add_filter( 'woocommerce_checkout_fields',                        [ __CLASS__, 'add_checkout_fields' ] );
        add_action( 'woocommerce_checkout_process',                       [ __CLASS__, 'validate_fields' ] );
        add_action( 'woocommerce_checkout_update_order_meta',             [ __CLASS__, 'save_fields' ] );
        add_action( 'woocommerce_admin_order_data_after_billing_address', [ __CLASS__, 'display_in_admin' ], 5 );
        add_filter( 'woocommerce_order_details_after_customer_details',   [ __CLASS__, 'display_on_my_account' ] );
        add_filter( 'woocommerce_checkout_get_value',                     [ __CLASS__, 'prefill_fields' ], 10, 2 );
        add_action( 'woocommerce_checkout_order_processed',               [ __CLASS__, 'save_to_user_meta' ], 10, 3 );
    }

    public static function add_checkout_fields( $fields ) {
        $channels = (array) get_option( 'orm_channels', array() );

        if ( in_array( 'whatsapp', $channels, true ) || in_array( 'sms', $channels, true ) ) {
            $fields['billing']['billing_whatsapp'] = array(
                'label'       => __( 'Phone for WhatsApp/SMS updates', 'order-receipts-sender-for-woocommerce' ),
                'placeholder' => '+358401234567',
                'required'    => false,
                'class'       => array( 'form-row-wide' ),
                'type'        => 'tel',
                'priority'    => 120,
            );
        }

        if ( in_array( 'telegram', $channels, true ) ) {
            $fields['billing']['billing_telegram_chat_id'] = array(
                'label'       => __( 'Telegram Chat ID (for order updates)', 'order-receipts-sender-for-woocommerce' ),
                'placeholder' => '123456789',
                'required'    => false,
                'class'       => array( 'form-row-wide' ),
                'type'        => 'text',
                'priority'    => 125,
                'description' => __( 'Optional. Start a chat with our bot on Telegram, then send /start to get your Chat ID.', 'order-receipts-sender-for-woocommerce' ),
            );
        }

        return $fields;
    }

    /**
     * Verify the WooCommerce checkout nonce.
     * Returns true if valid, false otherwise.
     */
    private static function verify_checkout_nonce(): bool {
        if ( ! isset( $_POST['woocommerce-process-checkout-nonce'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
            return false;
        }
        return (bool) wp_verify_nonce(
            sanitize_text_field( wp_unslash( $_POST['woocommerce-process-checkout-nonce'] ) ), // phpcs:ignore WordPress.Security.NonceVerification.Missing
            'woocommerce-process_checkout'
        );
    }

    public static function validate_fields() {
        if ( ! self::verify_checkout_nonce() ) {
            return;
        }

        // Nonce verified in verify_checkout_nonce() above.
        // phpcs:disable WordPress.Security.NonceVerification.Missing
        $phone = isset( $_POST['billing_whatsapp'] )
            ? sanitize_text_field( wp_unslash( $_POST['billing_whatsapp'] ) ) : '';
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        if ( ! empty( $phone ) && ! preg_match( '/^\+?[1-9]\d{6,14}$/', preg_replace( '/[\s\-\(\)]/', '', $phone ) ) ) {
            wc_add_notice( __( 'Please enter a valid phone number in international format (e.g. +358401234567).', 'order-receipts-sender-for-woocommerce' ), 'error' );
        }
    }

    public static function save_fields( $order_id ) {
        if ( ! self::verify_checkout_nonce() ) {
            return;
        }

        // Nonce verified in verify_checkout_nonce() above.
        // phpcs:disable WordPress.Security.NonceVerification.Missing
        if ( ! empty( $_POST['billing_whatsapp'] ) ) {
            update_post_meta( $order_id, '_billing_whatsapp', sanitize_text_field( wp_unslash( $_POST['billing_whatsapp'] ) ) );
        }
        if ( ! empty( $_POST['billing_telegram_chat_id'] ) ) {
            update_post_meta( $order_id, '_billing_telegram_chat_id', sanitize_text_field( wp_unslash( $_POST['billing_telegram_chat_id'] ) ) );
        }
        // phpcs:enable WordPress.Security.NonceVerification.Missing
    }

    public static function display_in_admin( $order ) {
        $phone = get_post_meta( $order->get_id(), '_billing_whatsapp', true );
        $tg    = get_post_meta( $order->get_id(), '_billing_telegram_chat_id', true );
        if ( $phone ) echo '<p><strong>' . esc_html__( 'WA/SMS Phone:', 'order-receipts-sender-for-woocommerce' ) . '</strong> ' . esc_html( $phone ) . '</p>';
        if ( $tg )    echo '<p><strong>' . esc_html__( 'Telegram Chat ID:', 'order-receipts-sender-for-woocommerce' ) . '</strong> ' . esc_html( $tg ) . '</p>';
    }

    public static function display_on_my_account( $order ) {
        $phone = $order->get_meta( '_billing_whatsapp' );
        $tg    = $order->get_meta( '_billing_telegram_chat_id' );
        if ( $phone ) echo '<tr><th>' . esc_html__( 'WA/SMS Phone:', 'order-receipts-sender-for-woocommerce' ) . '</th><td>' . esc_html( $phone ) . '</td></tr>';
        if ( $tg )    echo '<tr><th>' . esc_html__( 'Telegram Chat ID:', 'order-receipts-sender-for-woocommerce' ) . '</th><td>' . esc_html( $tg ) . '</td></tr>';
    }

    public static function prefill_fields( $value, $key ) {
        if ( ! is_user_logged_in() ) return $value;
        $uid = get_current_user_id();
        if ( 'billing_whatsapp' === $key ) {
            $saved = get_user_meta( $uid, 'billing_whatsapp', true );
            if ( $saved ) return $saved;
        }
        if ( 'billing_telegram_chat_id' === $key ) {
            $saved = get_user_meta( $uid, 'billing_telegram_chat_id', true );
            if ( $saved ) return $saved;
        }
        return $value;
    }

    public static function save_to_user_meta( $order_id, $posted_data, $order ) {
        if ( ! $order->get_user_id() ) return;
        $uid = $order->get_user_id();
        if ( ! empty( $posted_data['billing_whatsapp'] ) ) {
            update_user_meta( $uid, 'billing_whatsapp', sanitize_text_field( wp_unslash( $posted_data['billing_whatsapp'] ) ) );
        }
        if ( ! empty( $posted_data['billing_telegram_chat_id'] ) ) {
            update_user_meta( $uid, 'billing_telegram_chat_id', sanitize_text_field( wp_unslash( $posted_data['billing_telegram_chat_id'] ) ) );
        }
    }
}
