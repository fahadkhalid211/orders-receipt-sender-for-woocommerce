<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * ORM_OTP — Login / Registration OTP verification via WhatsApp, Telegram, or SMS.
 *
 * Flow:
 *  1. User enters their phone/chat-id on the login/register form → click "Send OTP".
 *  2. A 6-digit OTP is stored in the DB (expires in 10 min).
 *  3. OTP is dispatched on the enabled OTP channel.
 *  4. User enters the OTP → verified → logged in / registered.
 */
class ORM_OTP {

    const TABLE_SUFFIX = 'orm_otps';
    const OTP_TTL      = 600; // 10 minutes in seconds
    const OTP_LENGTH   = 6;

    public static function init() {
        if ( get_option( 'orm_otp_enabled', 'no' ) !== 'yes' ) return;

        // WordPress login form
        add_action( 'login_form',            [ __CLASS__, 'render_otp_fields' ] );
        add_action( 'login_enqueue_scripts', [ __CLASS__, 'enqueue_login_assets' ] );
        add_filter( 'authenticate',          [ __CLASS__, 'intercept_login' ], 30, 3 );

        // WooCommerce login form (My Account page)
        add_action( 'woocommerce_login_form',            [ __CLASS__, 'render_otp_fields_wc' ] );
        add_action( 'woocommerce_login_form_end',        [ __CLASS__, 'enqueue_wc_login_assets' ] );

        // AJAX: send OTP (logged-out and logged-in)
        add_action( 'wp_ajax_nopriv_orm_request_otp', [ __CLASS__, 'ajax_request_otp' ] );
        add_action( 'wp_ajax_orm_request_otp',        [ __CLASS__, 'ajax_request_otp' ] );

        // AJAX: verify OTP standalone (registration / profile)
        add_action( 'wp_ajax_nopriv_orm_verify_otp', [ __CLASS__, 'ajax_verify_otp' ] );
        add_action( 'wp_ajax_orm_verify_otp',        [ __CLASS__, 'ajax_verify_otp' ] );

        // WooCommerce registration
        if ( get_option( 'orm_otp_on_register', 'no' ) === 'yes' ) {
            add_action( 'woocommerce_register_form',  [ __CLASS__, 'render_register_otp_fields' ] );
            add_filter( 'woocommerce_process_registration_errors', [ __CLASS__, 'validate_register_otp_wc' ], 10, 3 );
        }

        // Scheduled cleanup
        add_action( 'orm_cleanup_otps', [ __CLASS__, 'cleanup_expired' ] );
        if ( ! wp_next_scheduled( 'orm_cleanup_otps' ) ) {
            wp_schedule_event( time(), 'hourly', 'orm_cleanup_otps' );
        }
    }

    // ── DB Table ──────────────────────────────────────────────────────────────

    public static function create_table() {
        global $wpdb;
        $table   = $wpdb->prefix . self::TABLE_SUFFIX;
        $charset = $wpdb->get_charset_collate();
        $sql     = "CREATE TABLE IF NOT EXISTS {$table} (
            id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            identifier VARCHAR(100)    NOT NULL,
            otp        VARCHAR(100)    NOT NULL,
            channel    VARCHAR(20)     NOT NULL DEFAULT 'sms',
            attempts   TINYINT        NOT NULL DEFAULT 0,
            expires_at DATETIME       NOT NULL,
            created_at DATETIME       NOT NULL,
            PRIMARY KEY (id),
            KEY identifier (identifier),
            KEY expires_at (expires_at)
        ) {$charset};";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    // ── Generate & store OTP ──────────────────────────────────────────────────

    private static function generate_otp(): string {
        $digits = '';
        for ( $i = 0; $i < self::OTP_LENGTH; $i++ ) {
            $digits .= (string) wp_rand( 0, 9 );
        }
        return $digits;
    }

    private static function store_otp( string $identifier, string $otp, string $channel ): void {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;

        // Delete any existing OTP for this identifier
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $wpdb->delete( $table, array( 'identifier' => $identifier ), array( '%s' ) );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $wpdb->insert(
            $table,
            array(
                'identifier' => $identifier,
                'otp'        => wp_hash( $otp ),  // store hash, not plaintext
                'channel'    => $channel,
                'attempts'   => 0,
                'expires_at' => gmdate( 'Y-m-d H:i:s', time() + self::OTP_TTL ),
                'created_at' => current_time( 'mysql', true ),
            ),
            array( '%s', '%s', '%s', '%d', '%s', '%s' )
        );
    }

    private static function verify_otp( string $identifier, string $otp ): bool {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;

        // $table is built from $wpdb->prefix (trusted) + a hardcoded class constant — safe to use directly.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
        $row = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' . $table . ' WHERE identifier = %s AND expires_at > UTC_TIMESTAMP() LIMIT 1', // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
                $identifier
            )
        );

        if ( ! $row ) return false;

        // Brute-force limit: max 5 attempts
        if ( (int) $row->attempts >= 5 ) {
            return false;
        }

        // Increment attempts
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $wpdb->update(
            $table,
            array( 'attempts' => (int) $row->attempts + 1 ),
            array( 'id' => $row->id ),
            array( '%d' ),
            array( '%d' )
        );

        if ( hash_equals( $row->otp, wp_hash( $otp ) ) ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            $wpdb->delete( $table, array( 'id' => $row->id ), array( '%d' ) );
            return true;
        }
        return false;
    }

    public static function cleanup_expired(): void {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;
        // $table is built from $wpdb->prefix (trusted) + a hardcoded class constant — safe to use directly.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared
        $wpdb->query( 'DELETE FROM ' . $table . ' WHERE expires_at < UTC_TIMESTAMP()' );
    }

    // ── WordPress Login form additions ────────────────────────────────────────

    public static function render_otp_fields() {
        $channel = get_option( 'orm_otp_channel', 'sms' );
        $label   = self::channel_label( $channel );
        ?>
        <div id="orm-otp-wrap" style="margin-bottom:16px;border-top:1px solid #ddd;padding-top:16px;">
            <p style="margin:0 0 8px;font-weight:600;">
                <?php esc_html_e( 'Or log in with OTP', 'order-receipts-sender-for-woocommerce' ); ?>
            </p>
            <label for="orm_otp_phone"><?php echo esc_html( $label ); ?></label>
            <input type="<?php echo ( 'telegram' === $channel ) ? 'text' : 'tel'; ?>"
                   name="orm_otp_identifier"
                   id="orm_otp_phone"
                   class="input"
                   placeholder="<?php echo ( 'telegram' === $channel ) ? '123456789' : '+358401234567'; ?>"
                   style="width:100%;margin-bottom:6px;" />
            <button type="button" id="orm-send-otp" class="button button-secondary" style="width:100%;">
                <?php
                /* translators: %s: messaging channel name e.g. "WhatsApp", "Telegram", "SMS" */
                printf( esc_html__( 'Send OTP via %s', 'order-receipts-sender-for-woocommerce' ), esc_html( self::channel_name( $channel ) ) );
                ?>
            </button>
            <div id="orm-otp-code-wrap" style="display:none;margin-top:8px;">
                <label for="orm_otp_code"><?php esc_html_e( 'Enter OTP', 'order-receipts-sender-for-woocommerce' ); ?></label>
                <input type="text" name="orm_otp_code" id="orm_otp_code" class="input"
                       maxlength="6" placeholder="______" autocomplete="one-time-code"
                       style="width:100%;letter-spacing:6px;font-size:18px;" />
            </div>
            <div id="orm-otp-msg" style="margin-top:6px;font-size:13px;"></div>
            <?php wp_nonce_field( 'orm_otp_nonce', 'orm_otp_nonce_field' ); ?>
        </div>
        <?php
    }

    // ── WooCommerce login form (My Account page) ──────────────────────────────

    public static function render_otp_fields_wc() {
        $channel = get_option( 'orm_otp_channel', 'sms' );
        $label   = self::channel_label( $channel );
        ?>
        <div class="orm-otp-section" style="margin:16px 0;border-top:1px solid #ddd;padding-top:16px;">
            <p style="margin:0 0 8px;font-weight:600;">
                <?php esc_html_e( 'Or log in with OTP', 'order-receipts-sender-for-woocommerce' ); ?>
            </p>
            <p class="form-row form-row-wide">
                <label for="orm_otp_phone_wc"><?php echo esc_html( $label ); ?></label>
                <input type="<?php echo ( 'telegram' === $channel ) ? 'text' : 'tel'; ?>"
                       name="orm_otp_identifier"
                       id="orm_otp_phone_wc"
                       class="input-text"
                       placeholder="<?php echo ( 'telegram' === $channel ) ? '123456789' : '+358401234567'; ?>" />
            </p>
            <p class="form-row form-row-wide">
                <button type="button" id="orm-send-otp" class="button">
                    <?php
                    /* translators: %s: messaging channel name e.g. "WhatsApp", "Telegram", "SMS" */
                    printf( esc_html__( 'Send OTP via %s', 'order-receipts-sender-for-woocommerce' ), esc_html( self::channel_name( $channel ) ) );
                    ?>
                </button>
            </p>
            <div id="orm-otp-code-wrap" style="display:none;">
                <p class="form-row form-row-wide">
                    <label for="orm_otp_code"><?php esc_html_e( 'Enter OTP', 'order-receipts-sender-for-woocommerce' ); ?></label>
                    <input type="text" name="orm_otp_code" id="orm_otp_code" class="input-text"
                           maxlength="6" placeholder="______" autocomplete="one-time-code"
                           style="letter-spacing:6px;font-size:18px;" />
                </p>
            </div>
            <div id="orm-otp-msg" style="font-size:13px;margin-bottom:10px;"></div>
            <?php wp_nonce_field( 'orm_otp_nonce', 'orm_otp_nonce_field' ); ?>
        </div>
        <?php
    }

    public static function enqueue_wc_login_assets() {
        if ( ! is_account_page() ) return;
        self::enqueue_login_assets();
    }

    // ── WooCommerce Registration OTP fields ───────────────────────────────────

    public static function render_register_otp_fields() {
        $channel = get_option( 'orm_otp_channel', 'sms' );
        ?>
        <p class="form-row form-row-wide">
            <label><?php echo esc_html( self::channel_label( $channel ) ); ?> <span class="required">*</span></label>
            <input type="<?php echo ( 'telegram' === $channel ) ? 'text' : 'tel'; ?>"
                   name="orm_otp_identifier" id="orm_reg_otp_phone" class="input-text"
                   placeholder="<?php echo ( 'telegram' === $channel ) ? '123456789' : '+358401234567'; ?>" />
        </p>
        <p class="form-row form-row-wide">
            <button type="button" id="orm-reg-send-otp" class="button">
                <?php
                /* translators: %s: messaging channel name e.g. "WhatsApp", "Telegram", "SMS" */
                printf( esc_html__( 'Send OTP via %s', 'order-receipts-sender-for-woocommerce' ), esc_html( self::channel_name( $channel ) ) );
                ?>
            </button>
        </p>
        <p class="form-row form-row-wide" id="orm-reg-otp-code-wrap" style="display:none;">
            <label><?php esc_html_e( 'Enter OTP', 'order-receipts-sender-for-woocommerce' ); ?> <span class="required">*</span></label>
            <input type="text" name="orm_otp_code" id="orm_reg_otp_code" class="input-text"
                   maxlength="6" placeholder="______" autocomplete="one-time-code"
                   style="letter-spacing:4px;" />
        </p>
        <div id="orm-reg-otp-msg" style="font-size:13px;margin-bottom:10px;color:#c00;"></div>
        <?php wp_nonce_field( 'orm_otp_nonce', 'orm_otp_nonce_field' ); ?>
        <?php
    }

    // ── AJAX: request OTP ─────────────────────────────────────────────────────

    public static function ajax_request_otp() {
        if ( ! isset( $_POST['nonce'] ) ||
             ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'orm_otp_nonce' )
        ) {
            wp_send_json_error( __( 'Security check failed.', 'order-receipts-sender-for-woocommerce' ) );
        }

        $identifier = sanitize_text_field( wp_unslash( $_POST['identifier'] ?? '' ) );
        if ( empty( $identifier ) ) {
            wp_send_json_error( __( 'Please enter your phone number or Telegram Chat ID.', 'order-receipts-sender-for-woocommerce' ) );
        }

        $channel = get_option( 'orm_otp_channel', 'sms' );
        $otp     = self::generate_otp();
        self::store_otp( $identifier, $otp, $channel );

        $message = sprintf(
            /* translators: 1: site name, 2: 6-digit OTP code */
            __( 'Your %1$s login code is: *%2$s*. Valid for 10 minutes. Do not share it.', 'order-receipts-sender-for-woocommerce' ),
            get_bloginfo( 'name' ),
            $otp
        );

        $sender = new ORM_Sender();
        $result = $sender->send( $channel, $identifier, $message );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( $result->get_error_message() );
        }

        wp_send_json_success( __( 'OTP sent! Check your messages.', 'order-receipts-sender-for-woocommerce' ) );
    }

    // ── AJAX: verify OTP standalone (registration / profile) ─────────────────

    public static function ajax_verify_otp() {
        if ( ! isset( $_POST['nonce'] ) ||
             ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'orm_otp_nonce' )
        ) {
            wp_send_json_error( __( 'Security check failed.', 'order-receipts-sender-for-woocommerce' ) );
        }

        $identifier = sanitize_text_field( wp_unslash( $_POST['identifier'] ?? '' ) );
        $code       = sanitize_text_field( wp_unslash( $_POST['code'] ?? '' ) );

        if ( self::verify_otp( $identifier, $code ) ) {
            wp_send_json_success( __( 'OTP verified.', 'order-receipts-sender-for-woocommerce' ) );
        } else {
            wp_send_json_error( __( 'Invalid or expired OTP. Please try again.', 'order-receipts-sender-for-woocommerce' ) );
        }
    }

    // ── Login intercept ───────────────────────────────────────────────────────

    public static function intercept_login( $user, $username, $password ) {
        $otp_required = get_option( 'orm_otp_required', 'yes' ) === 'yes';
        $otp_submitted = ! empty( $_POST['orm_otp_code'] ) && ! empty( $_POST['orm_otp_identifier'] );

        // If OTP is NOT required (optional mode) and user didn't submit OTP fields → allow normal login
        if ( ! $otp_required && ! $otp_submitted ) {
            return $user;
        }

        // If OTP IS required and user didn't submit OTP fields → block login
        if ( $otp_required && ! $otp_submitted ) {
            // Don't block if the form was just loaded (no username submitted either)
            if ( empty( $username ) && empty( $password ) ) {
                return $user;
            }
            return new WP_Error(
                'orm_otp_required',
                __( 'You must verify your identity with an OTP before logging in. Enter your phone/Chat ID above and click "Send OTP".', 'order-receipts-sender-for-woocommerce' )
            );
        }

        // OTP fields were submitted — validate nonce
        if ( ! isset( $_POST['orm_otp_nonce_field'] ) ||
             ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['orm_otp_nonce_field'] ) ), 'orm_otp_nonce' )
        ) {
            return new WP_Error( 'orm_otp_fail', __( 'Security check failed.', 'order-receipts-sender-for-woocommerce' ) );
        }

        $identifier = sanitize_text_field( wp_unslash( $_POST['orm_otp_identifier'] ) );
        $code       = sanitize_text_field( wp_unslash( $_POST['orm_otp_code'] ) );

        if ( ! self::verify_otp( $identifier, $code ) ) {
            return new WP_Error( 'orm_otp_fail', __( 'Invalid or expired OTP. Please try again.', 'order-receipts-sender-for-woocommerce' ) );
        }

        // OTP valid — find the user by username/email first
        $wp_user = null;
        if ( ! empty( $username ) ) {
            $wp_user = get_user_by( 'login', $username );
            if ( ! $wp_user ) {
                $wp_user = get_user_by( 'email', $username );
            }
        }

        // Fall back: search by phone/chat-id meta fields
        if ( ! $wp_user ) {
            foreach ( array( 'billing_phone', 'billing_whatsapp', 'billing_telegram_chat_id' ) as $meta_key ) {
                $users = get_users( array(
                    'meta_key'   => $meta_key,   // phpcs:ignore WordPress.DB.SlowDBQuery
                    'meta_value' => $identifier, // phpcs:ignore WordPress.DB.SlowDBQuery
                    'number'     => 1,
                ) );
                if ( ! empty( $users ) ) {
                    $wp_user = $users[0];
                    break;
                }
            }
        }

        if ( $wp_user ) {
            return $wp_user;
        }

        return new WP_Error( 'orm_otp_fail', __( 'No account found for that identifier. Please also enter your username or email above.', 'order-receipts-sender-for-woocommerce' ) );
    }

    // ── WooCommerce registration validation ───────────────────────────────────

    /**
     * Used with woocommerce_process_registration_errors filter (receives WP_Error object).
     */
    public static function validate_register_otp_wc( $errors, $username, $email ) {
        if ( ! isset( $_POST['orm_otp_nonce_field'] ) ||
             ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['orm_otp_nonce_field'] ) ), 'orm_otp_nonce' )
        ) {
            $errors->add( 'orm_otp', __( 'Security check failed.', 'order-receipts-sender-for-woocommerce' ) );
            return $errors;
        }

        $identifier = sanitize_text_field( wp_unslash( $_POST['orm_otp_identifier'] ?? '' ) );
        $code       = sanitize_text_field( wp_unslash( $_POST['orm_otp_code'] ?? '' ) );

        if ( empty( $identifier ) || empty( $code ) ) {
            $errors->add( 'orm_otp', __( 'Please verify your phone number with an OTP before registering.', 'order-receipts-sender-for-woocommerce' ) );
            return $errors;
        }

        if ( ! self::verify_otp( $identifier, $code ) ) {
            $errors->add( 'orm_otp', __( 'Invalid or expired OTP. Please try again.', 'order-receipts-sender-for-woocommerce' ) );
        }

        return $errors;
    }

    // ── Frontend assets ───────────────────────────────────────────────────────

    public static function enqueue_login_assets() {
        wp_enqueue_script(
            'orm-otp-login',
            ORM_PLUGIN_URL . 'assets/otp-login.js',
            array( 'jquery' ),
            ORM_VERSION,
            true
        );
        wp_localize_script( 'orm-otp-login', 'ormOtp', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'orm_otp_nonce' ),
        ) );
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static function channel_name( string $channel ): string {
        $map = array(
            'whatsapp' => 'WhatsApp',
            'telegram' => 'Telegram',
            'sms'      => 'SMS',
        );
        return $map[ $channel ] ?? ucfirst( $channel );
    }

    private static function channel_label( string $channel ): string {
        if ( 'telegram' === $channel ) {
            return __( 'Your Telegram Chat ID', 'order-receipts-sender-for-woocommerce' );
        }
        return __( 'Your Phone Number', 'order-receipts-sender-for-woocommerce' );
    }
}
