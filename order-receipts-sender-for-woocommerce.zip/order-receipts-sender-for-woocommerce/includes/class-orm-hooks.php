<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class ORM_Hooks {

    public static function init() {
        add_action( 'woocommerce_order_status_changed',            [ __CLASS__, 'on_status_changed' ], 10, 4 );
        add_action( 'woocommerce_checkout_order_processed',        [ __CLASS__, 'on_new_order' ],      10, 3 );
        add_action( 'woocommerce_order_actions',                   [ __CLASS__, 'add_order_action' ] );
        add_action( 'woocommerce_order_action_orm_resend_receipt', [ __CLASS__, 'manual_resend' ] );
        add_action( 'woocommerce_admin_order_data_after_billing_address', [ __CLASS__, 'show_contact_in_order' ], 10, 1 );
    }

    // ── Triggers ──────────────────────────────────────────────────────────────

    public static function on_status_changed( $order_id, $old_status, $new_status, $order ) {
        if ( get_option( 'orm_enabled', 'yes' ) !== 'yes' ) return;
        if ( $new_status !== get_option( 'orm_trigger_status', 'processing' ) ) return;
        // Avoid duplicate sends if on_new_order already fired for 'pending'
        if ( $new_status === $old_status ) return;
        self::send_receipt( $order );
    }

    public static function on_new_order( $order_id, $posted_data, $order ) {
        if ( get_option( 'orm_enabled', 'yes' ) !== 'yes' ) return;
        if ( 'pending' !== get_option( 'orm_trigger_status', 'processing' ) ) return;
        if ( 'pending' !== $order->get_status() ) return;
        self::send_receipt( $order );
    }

    // ── Core: send on all enabled channels ────────────────────────────────────

    public static function send_receipt( $order ) {
        if ( ! $order instanceof WC_Order ) {
            $order = wc_get_order( $order );
        }
        if ( ! $order ) return;

        $channels = (array) get_option( 'orm_channels', array( 'telegram' ) );
        $sender   = new ORM_Sender();
        $notes    = array();

        foreach ( $channels as $channel ) {
            $result = self::send_on_channel( $sender, $channel, $order );
            if ( is_wp_error( $result ) ) {
                $notes[] = sprintf( '❌ %s failed: %s', ucfirst( $channel ), $result->get_error_message() );
            } else {
                $notes[] = sprintf( '✅ Sent via %s', ucfirst( $channel ) );
            }
        }

        if ( ! empty( $notes ) ) {
            $order->add_order_note( implode( ' | ', $notes ) );
            $order->update_meta_data( '_orm_receipt_sent', current_time( 'mysql' ) );
            $order->update_meta_data( '_orm_receipt_channels', implode( ', ', $channels ) );
            $order->save();
        }
    }

    // ── Per-channel send ──────────────────────────────────────────────────────

    private static function send_on_channel( ORM_Sender $sender, string $channel, WC_Order $order ) {
        if ( 'telegram' === $channel ) {
            $recipient = $order->get_meta( '_billing_telegram_chat_id' );
            if ( empty( $recipient ) ) {
                $recipient = get_option( 'orm_telegram_admin_chat_id', '' );
            }
            if ( empty( $recipient ) ) {
                return new WP_Error( 'missing_recipient', 'Telegram: No Chat ID found.' );
            }
            $message = self::build_message( $order, 'telegram' );

        } elseif ( 'sms' === $channel ) {
            $recipient = $order->get_meta( '_billing_whatsapp' );
            if ( empty( $recipient ) ) {
                $recipient = $order->get_billing_phone();
            }
            if ( empty( $recipient ) ) {
                return new WP_Error( 'missing_recipient', 'SMS: No phone number found.' );
            }
            $message = self::build_message( $order, 'sms' );

        } else {
            // whatsapp
            $recipient = $order->get_meta( '_billing_whatsapp' );
            if ( empty( $recipient ) ) {
                $recipient = $order->get_billing_phone();
            }
            if ( empty( $recipient ) ) {
                return new WP_Error( 'missing_recipient', 'WhatsApp: No phone number found.' );
            }
            $message = self::build_message( $order, 'whatsapp' );
        }

        return $sender->send( $channel, $recipient, $message );
    }

    // ── Build message ─────────────────────────────────────────────────────────

    private static function build_message( WC_Order $order, string $channel ): string {
        $template = ( 'sms' === $channel )
            ? get_option( 'orm_sms_template', order_receipt_messenger_default_sms_template() )
            : get_option( 'orm_message_template', order_receipt_messenger_default_template() );

        $items_text = '';
        foreach ( $order->get_items() as $item ) {
            $items_text .= sprintf(
                "  %s x%d - %s\n",
                $item->get_name(),
                $item->get_quantity(),
                html_entity_decode( wp_strip_all_tags( wc_price( $item->get_total() ) ) )
            );
        }

        $replacements = array(
            '{customer_name}'   => $order->get_formatted_billing_full_name(),
            '{site_name}'       => get_bloginfo( 'name' ),
            '{order_number}'    => $order->get_order_number(),
            '{order_date}'      => wc_format_datetime( $order->get_date_created() ),
            '{order_status}'    => wc_get_order_status_name( $order->get_status() ),
            '{order_items}'     => rtrim( $items_text ),
            '{order_total}'     => html_entity_decode( wp_strip_all_tags( wc_price( $order->get_total(), array( 'currency' => $order->get_currency() ) ) ) ),
            '{order_url}'       => $order->get_view_order_url(),
            '{billing_address}' => preg_replace( '/<br\s*\/?>/i', ', ', $order->get_formatted_billing_address() ),
        );

        return str_replace( array_keys( $replacements ), array_values( $replacements ), $template );
    }

    // ── Admin order action ────────────────────────────────────────────────────

    public static function add_order_action( $actions ) {
        $actions['orm_resend_receipt'] = __( '📱 Resend Messaging Receipt', 'order-receipts-sender-for-woocommerce' );
        return $actions;
    }

    public static function manual_resend( $order ) {
        self::send_receipt( $order );
    }

    // ── Admin order detail display ────────────────────────────────────────────

    public static function show_contact_in_order( $order ) {
        $phone    = $order->get_meta( '_billing_whatsapp' );
        $tg_id    = $order->get_meta( '_billing_telegram_chat_id' );
        $sent_at  = $order->get_meta( '_orm_receipt_sent' );
        $channels = $order->get_meta( '_orm_receipt_channels' );

        if ( $phone ) {
            echo '<p><strong>' . esc_html__( 'Messenger Phone:', 'order-receipts-sender-for-woocommerce' ) . '</strong> ' . esc_html( $phone ) . '</p>';
        }
        if ( $tg_id ) {
            echo '<p><strong>' . esc_html__( 'Telegram Chat ID:', 'order-receipts-sender-for-woocommerce' ) . '</strong> ' . esc_html( $tg_id ) . '</p>';
        }
        if ( $sent_at ) {
            echo '<p><small>✅ ' . esc_html__( 'Receipt sent via', 'order-receipts-sender-for-woocommerce' ) . ' ' . esc_html( $channels ) . ' &mdash; ' . esc_html( $sent_at ) . '</small></p>';
        }
    }
}
