<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class ORM_Settings {

    public static function init() {
        add_filter( 'woocommerce_settings_tabs_array', [ __CLASS__, 'add_settings_tab' ], 50 );
        add_action( 'woocommerce_settings_tabs_orm',   [ __CLASS__, 'settings_tab' ] );
        add_action( 'woocommerce_update_options_orm',  [ __CLASS__, 'update_settings' ] );
        add_action( 'admin_enqueue_scripts',           [ __CLASS__, 'enqueue_admin_assets' ] );
        add_action( 'wp_ajax_orm_send_test',           [ __CLASS__, 'ajax_send_test' ] );
    }

    public static function add_settings_tab( $tabs ) {
        $tabs['orm'] = __( '📱 Messaging Receipt', 'order-receipts-sender-for-woocommerce' );
        return $tabs;
    }

    public static function settings_tab() {
        woocommerce_admin_fields( self::get_settings() );
    }

    public static function update_settings() {
        woocommerce_update_options( self::get_settings() );
        // Multicheck (channels) is not saved by woocommerce_update_options — handle manually
        if ( isset( $_POST['orm_settings_nonce'] ) &&
             wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['orm_settings_nonce'] ) ), 'orm_save_settings' )
        ) {
            $channels = isset( $_POST['orm_channels'] ) ? array_map( 'sanitize_text_field', wp_unslash( (array) $_POST['orm_channels'] ) ) : array();
            update_option( 'orm_channels', $channels );
        }
    }

    public static function enqueue_admin_assets( $hook ) {
        if ( strpos( $hook, 'woocommerce' ) === false ) return;
        wp_enqueue_style( 'orm-admin', ORM_PLUGIN_URL . 'assets/admin.css', array(), ORM_VERSION );
        wp_enqueue_script( 'orm-admin', ORM_PLUGIN_URL . 'assets/admin.js', array( 'jquery' ), ORM_VERSION, true );
        wp_localize_script( 'orm-admin', 'ormReceipt', array(
            'ajax_url'         => admin_url( 'admin-ajax.php' ),
            'nonce'            => wp_create_nonce( 'orm_test_nonce' ),
            'settings_nonce'   => wp_create_nonce( 'orm_save_settings' ),
            'active_channels'  => (array) get_option( 'orm_channels', array( 'telegram' ) ),
            'wa_provider'      => get_option( 'orm_whatsapp_provider', 'ultramsg' ),
            'sms_provider'     => get_option( 'orm_sms_provider', 'textbelt' ),
            'otp_channel'      => get_option( 'orm_otp_channel', 'sms' ),
        ) );
    }

    public static function ajax_send_test() {
        check_ajax_referer( 'orm_test_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_send_json_error( 'Unauthorized.' );
        }

        $channel   = sanitize_text_field( wp_unslash( $_POST['channel'] ?? 'telegram' ) );
        $recipient = sanitize_text_field( wp_unslash( $_POST['recipient'] ?? '' ) );

        if ( empty( $recipient ) ) {
            $label = ( 'telegram' === $channel ) ? 'Chat ID' : 'phone number';
            wp_send_json_error( 'Please enter a ' . $label . '.' );
        }

        $message = '✅ *Order Receipt Messenger v2 — Test*' . "\n\n"
            . 'Channel: ' . strtoupper( $channel ) . "\n"
            . 'Store: ' . get_bloginfo( 'name' ) . "\n\n"
            . 'Your integration is working correctly! 🎉';

        $sender = new ORM_Sender();
        $result = $sender->send( $channel, $recipient, $message );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( $result->get_error_message() );
        }
        wp_send_json_success( 'Test sent successfully via ' . strtoupper( $channel ) . '!' );
    }

    public static function get_settings() {
        return apply_filters( 'order_receipt_messenger_settings', array(

            // ── General ───────────────────────────────────────────────────────
            array(
                'title' => __( 'Order Receipt Messenger v2', 'order-receipts-sender-for-woocommerce' ),
                'type'  => 'title',
                'desc'  => __( 'Send order receipts on multiple channels simultaneously. Email is never disabled.', 'order-receipts-sender-for-woocommerce' ),
                'id'    => 'orm_general_section',
            ),
            array(
                'title'   => __( 'Enable Receipts', 'order-receipts-sender-for-woocommerce' ),
                'type'    => 'checkbox',
                'desc'    => __( 'Send messaging receipts alongside the default WooCommerce email.', 'order-receipts-sender-for-woocommerce' ),
                'id'      => 'orm_enabled',
                'default' => 'yes',
            ),
            array(
                'title'   => __( 'Trigger on Status', 'order-receipts-sender-for-woocommerce' ),
                'type'    => 'select',
                'id'      => 'orm_trigger_status',
                'default' => 'processing',
                'options' => array(
                    'pending'    => __( 'Pending Payment', 'order-receipts-sender-for-woocommerce' ),
                    'processing' => __( 'Processing (recommended)', 'order-receipts-sender-for-woocommerce' ),
                    'completed'  => __( 'Completed', 'order-receipts-sender-for-woocommerce' ),
                    'on-hold'    => __( 'On Hold', 'order-receipts-sender-for-woocommerce' ),
                ),
                'desc' => '',
            ),
            array( 'type' => 'sectionend', 'id' => 'orm_general_section' ),

            // ── Active Channels (rendered via custom HTML) ────────────────────
            array(
                'title' => __( 'Active Channels', 'order-receipts-sender-for-woocommerce' ),
                'type'  => 'title',
                'desc'  => __( 'Select one or more channels. All enabled channels will receive the receipt simultaneously.', 'order-receipts-sender-for-woocommerce' ),
                'id'    => 'orm_channels_section',
            ),
            array(
                'type' => 'orm_channels_checkboxes',
                'id'   => 'orm_channels',
            ),
            array( 'type' => 'sectionend', 'id' => 'orm_channels_section' ),

            // ── WhatsApp Provider ─────────────────────────────────────────────
            array(
                'title' => __( 'WhatsApp Provider', 'order-receipts-sender-for-woocommerce' ),
                'type'  => 'title',
                'desc'  => __( 'Only relevant if WhatsApp is an active channel above.', 'order-receipts-sender-for-woocommerce' ),
                'id'    => 'orm_wa_provider_section',
            ),
            array(
                'title'   => __( 'WhatsApp Provider', 'order-receipts-sender-for-woocommerce' ),
                'type'    => 'select',
                'id'      => 'orm_whatsapp_provider',
                'default' => 'ultramsg',
                'options' => array(
                    'ultramsg'          => __( 'UltraMsg — Free trial, easiest setup', 'order-receipts-sender-for-woocommerce' ),
                    'whatsapp_business' => __( 'Meta WhatsApp Business API — Official, free up to 1k/mo', 'order-receipts-sender-for-woocommerce' ),
                    'callmebot'         => __( 'CallMeBot — Free personal use', 'order-receipts-sender-for-woocommerce' ),
                    'twilio_wa'         => __( 'Twilio WhatsApp — Paid production', 'order-receipts-sender-for-woocommerce' ),
                ),
                'desc' => '',
            ),
            array( 'type' => 'sectionend', 'id' => 'orm_wa_provider_section' ),

            // ── UltraMsg ──────────────────────────────────────────────────────
            array(
                'title' => __( 'UltraMsg Credentials', 'order-receipts-sender-for-woocommerce' ),
                'type'  => 'title',
                'desc'  => '<strong>Free trial — no opt-in required.</strong> Sign up at <a href="https://ultramsg.com" target="_blank">ultramsg.com</a>, create an instance, scan the QR code with WhatsApp, then copy Instance ID and Token.',
                'id'    => 'orm_ultramsg_section',
            ),
            array(
                'title'       => __( 'Instance ID', 'order-receipts-sender-for-woocommerce' ),
                'type'        => 'text',
                'id'          => 'orm_ultramsg_instance',
                'placeholder' => 'instance12345',
                'class'       => 'orm-field-ultramsg',
                'desc'        => '',
            ),
            array(
                'title'       => __( 'Token', 'order-receipts-sender-for-woocommerce' ),
                'type'        => 'password',
                'id'          => 'orm_ultramsg_token',
                'placeholder' => 'Your UltraMsg token',
                'class'       => 'orm-field-ultramsg',
                'desc'        => '',
            ),
            array( 'type' => 'sectionend', 'id' => 'orm_ultramsg_section' ),

            // ── Meta WABA ─────────────────────────────────────────────────────
            array(
                'title' => __( 'WhatsApp Business API (Meta)', 'order-receipts-sender-for-woocommerce' ),
                'type'  => 'title',
                'desc'  => '<strong>Free up to 1,000 conversations/month.</strong> Create a <a href="https://developers.facebook.com/apps/" target="_blank">Meta Developer App</a>, add WhatsApp product, verify a phone number, then copy Phone Number ID and System User Access Token.',
                'id'    => 'orm_waba_section',
            ),
            array(
                'title'       => __( 'Phone Number ID', 'order-receipts-sender-for-woocommerce' ),
                'type'        => 'text',
                'id'          => 'orm_waba_phone_number_id',
                'placeholder' => '1234567890123456',
                'class'       => 'orm-field-waba',
                'desc'        => '',
            ),
            array(
                'title'       => __( 'Access Token', 'order-receipts-sender-for-woocommerce' ),
                'type'        => 'password',
                'id'          => 'orm_waba_access_token',
                'placeholder' => 'EAAxxxxxxx',
                'class'       => 'orm-field-waba',
                'desc'        => '',
            ),
            array( 'type' => 'sectionend', 'id' => 'orm_waba_section' ),

            // ── CallMeBot ─────────────────────────────────────────────────────
            array(
                'title' => __( 'CallMeBot API Key', 'order-receipts-sender-for-woocommerce' ),
                'type'  => 'title',
                'desc'  => 'Save <strong>+34 644 61 09 91</strong> in your contacts, then send <code>I allow callmebot to send me messages</code> to that number on WhatsApp to get your API key.',
                'id'    => 'orm_callmebot_section',
            ),
            array(
                'title'       => __( 'API Key', 'order-receipts-sender-for-woocommerce' ),
                'type'        => 'text',
                'id'          => 'orm_callmebot_apikey',
                'placeholder' => 'Your CallMeBot API key',
                'class'       => 'orm-field-callmebot',
                'desc'        => '',
            ),
            array( 'type' => 'sectionend', 'id' => 'orm_callmebot_section' ),

            // ── Telegram ──────────────────────────────────────────────────────
            array(
                'title' => __( 'Telegram Bot Settings', 'order-receipts-sender-for-woocommerce' ),
                'type'  => 'title',
                'desc'  => '<strong>Free, 2-minute setup:</strong> Message <a href="https://t.me/BotFather" target="_blank">@BotFather</a> on Telegram &rarr; <code>/newbot</code> &rarr; copy the token. Start a chat with your bot, then visit <code>https://api.telegram.org/bot<em>TOKEN</em>/getUpdates</code> to find your Chat ID.',
                'id'    => 'orm_telegram_section',
            ),
            array(
                'title'       => __( 'Bot Token', 'order-receipts-sender-for-woocommerce' ),
                'type'        => 'text',
                'id'          => 'orm_telegram_bot_token',
                'placeholder' => '123456789:AAxxxxxxx',
                'class'       => 'orm-field-telegram',
                'desc'        => '',
            ),
            array(
                'title'       => __( 'Admin / Fallback Chat ID', 'order-receipts-sender-for-woocommerce' ),
                'type'        => 'text',
                'id'          => 'orm_telegram_admin_chat_id',
                'placeholder' => '123456789',
                'class'       => 'orm-field-telegram',
                'desc'        => __( 'Used when a customer has no Telegram Chat ID stored. Also used for test messages.', 'order-receipts-sender-for-woocommerce' ),
            ),
            array( 'type' => 'sectionend', 'id' => 'orm_telegram_section' ),

            // ── SMS Provider ──────────────────────────────────────────────────
            array(
                'title' => __( 'SMS Provider', 'order-receipts-sender-for-woocommerce' ),
                'type'  => 'title',
                'desc'  => __( 'Only relevant if SMS is an active channel above.', 'order-receipts-sender-for-woocommerce' ),
                'id'    => 'orm_sms_provider_section',
            ),
            array(
                'title'   => __( 'SMS Provider', 'order-receipts-sender-for-woocommerce' ),
                'type'    => 'select',
                'id'      => 'orm_sms_provider',
                'default' => 'textbelt',
                'options' => array(
                    'textbelt'  => __( 'TextBelt — 1 free SMS/day, paid for more', 'order-receipts-sender-for-woocommerce' ),
                    'twilio_sms' => __( 'Twilio SMS — Paid production', 'order-receipts-sender-for-woocommerce' ),
                ),
                'desc' => '',
            ),
            array( 'type' => 'sectionend', 'id' => 'orm_sms_provider_section' ),

            // ── TextBelt ──────────────────────────────────────────────────────
            array(
                'title' => __( 'TextBelt Settings', 'order-receipts-sender-for-woocommerce' ),
                'type'  => 'title',
                'desc'  => '<strong>1 free SMS per day</strong> using key <code>textbelt</code> (leave blank for free). For more, buy credits at <a href="https://textbelt.com" target="_blank">textbelt.com</a> and paste your paid key below.',
                'id'    => 'orm_textbelt_section',
            ),
            array(
                'title'       => __( 'API Key', 'order-receipts-sender-for-woocommerce' ),
                'type'        => 'text',
                'id'          => 'orm_textbelt_key',
                'placeholder' => 'textbelt  (or your paid key)',
                'class'       => 'orm-field-textbelt',
                'desc'        => '',
            ),
            array( 'type' => 'sectionend', 'id' => 'orm_textbelt_section' ),

            // ── Twilio (shared for WA + SMS) ───────────────────────────────────
            array(
                'title' => __( 'Twilio Credentials', 'order-receipts-sender-for-woocommerce' ),
                'type'  => 'title',
                'desc'  => '<strong>&#9888; Sandbox note:</strong> WhatsApp sandbox messages are logged as sent but not delivered unless the recipient texted <code>join &lt;keyword&gt;</code> first. Use an approved number for production.',
                'id'    => 'orm_twilio_section',
            ),
            array(
                'title'       => __( 'Account SID', 'order-receipts-sender-for-woocommerce' ),
                'type'        => 'text',
                'id'          => 'orm_twilio_sid',
                'placeholder' => 'ACxxxxxxxxxxxxxxxx',
                'class'       => 'orm-field-twilio',
                'desc'        => '',
            ),
            array(
                'title'       => __( 'Auth Token', 'order-receipts-sender-for-woocommerce' ),
                'type'        => 'password',
                'id'          => 'orm_twilio_token',
                'placeholder' => 'Your Twilio Auth Token',
                'class'       => 'orm-field-twilio',
                'desc'        => '',
            ),
            array(
                'title'       => __( 'WhatsApp From Number', 'order-receipts-sender-for-woocommerce' ),
                'type'        => 'text',
                'id'          => 'orm_twilio_wa_from',
                'placeholder' => '+14155238886',
                'class'       => 'orm-field-twilio',
                'desc'        => __( 'Twilio WhatsApp number in E.164 format.', 'order-receipts-sender-for-woocommerce' ),
            ),
            array(
                'title'       => __( 'SMS From Number', 'order-receipts-sender-for-woocommerce' ),
                'type'        => 'text',
                'id'          => 'orm_twilio_sms_from',
                'placeholder' => '+14155238886',
                'class'       => 'orm-field-twilio',
                'desc'        => __( 'Twilio SMS number in E.164 format.', 'order-receipts-sender-for-woocommerce' ),
            ),
            array( 'type' => 'sectionend', 'id' => 'orm_twilio_section' ),

            // ── Message Templates ─────────────────────────────────────────────
            array(
                'title' => __( 'Message Templates', 'order-receipts-sender-for-woocommerce' ),
                'type'  => 'title',
                'desc'  => __( 'Use <code>*text*</code> for bold (WhatsApp/Telegram). Placeholders: <code>{customer_name}</code> <code>{site_name}</code> <code>{order_number}</code> <code>{order_date}</code> <code>{order_status}</code> <code>{order_items}</code> <code>{order_total}</code> <code>{order_url}</code> <code>{billing_address}</code>', 'order-receipts-sender-for-woocommerce' ),
                'id'    => 'orm_template_section',
            ),
            array(
                'title'   => __( 'WhatsApp / Telegram Template', 'order-receipts-sender-for-woocommerce' ),
                'type'    => 'textarea',
                'id'      => 'orm_message_template',
                'default' => order_receipt_messenger_default_template(),
                'css'     => 'width:100%;height:200px;font-family:monospace;',
                'desc'    => '',
            ),
            array(
                'title'   => __( 'SMS Template', 'order-receipts-sender-for-woocommerce' ),
                'type'    => 'textarea',
                'id'      => 'orm_sms_template',
                'default' => order_receipt_messenger_default_sms_template(),
                'css'     => 'width:100%;height:80px;font-family:monospace;',
                'desc'    => __( 'Keep SMS under 160 characters to avoid split messages.', 'order-receipts-sender-for-woocommerce' ),
            ),
            array( 'type' => 'sectionend', 'id' => 'orm_template_section' ),

            // ── OTP Settings ──────────────────────────────────────────────────
            array(
                'title' => __( 'Login OTP Settings', 'order-receipts-sender-for-woocommerce' ),
                'type'  => 'title',
                'desc'  => __( 'Send a one-time password via WhatsApp, Telegram, or SMS when customers log in or register.', 'order-receipts-sender-for-woocommerce' ),
                'id'    => 'orm_otp_section',
            ),
            array(
                'title'   => __( 'Enable OTP Login', 'order-receipts-sender-for-woocommerce' ),
                'type'    => 'checkbox',
                'desc'    => __( 'Add an OTP option to the WooCommerce login form.', 'order-receipts-sender-for-woocommerce' ),
                'id'      => 'orm_otp_enabled',
                'default' => 'no',
            ),
            array(
                'title'   => __( 'Require OTP to Login', 'order-receipts-sender-for-woocommerce' ),
                'type'    => 'checkbox',
                'desc'    => __( 'Block password-only login — customers MUST verify via OTP to log in. If unchecked, OTP is optional (customers can still log in with username + password).', 'order-receipts-sender-for-woocommerce' ),
                'id'      => 'orm_otp_required',
                'default' => 'yes',
            ),
            array(
                'title'   => __( 'Require OTP on Registration', 'order-receipts-sender-for-woocommerce' ),
                'type'    => 'checkbox',
                'desc'    => __( 'Customers must verify their phone number with an OTP before completing registration.', 'order-receipts-sender-for-woocommerce' ),
                'id'      => 'orm_otp_on_register',
                'default' => 'no',
            ),
            array(
                'title'   => __( 'OTP Channel', 'order-receipts-sender-for-woocommerce' ),
                'type'    => 'select',
                'id'      => 'orm_otp_channel',
                'default' => 'sms',
                'options' => array(
                    'sms'      => __( 'SMS (most universal)', 'order-receipts-sender-for-woocommerce' ),
                    'whatsapp' => __( 'WhatsApp', 'order-receipts-sender-for-woocommerce' ),
                    'telegram' => __( 'Telegram (requires customer Chat ID)', 'order-receipts-sender-for-woocommerce' ),
                ),
                'desc' => '',
            ),
            array( 'type' => 'sectionend', 'id' => 'orm_otp_section' ),

            // ── Test ──────────────────────────────────────────────────────────
            array(
                'title' => __( 'Send Test Message', 'order-receipts-sender-for-woocommerce' ),
                'type'  => 'title',
                'desc'  => __( 'Test each channel independently. Save settings first.', 'order-receipts-sender-for-woocommerce' ),
                'id'    => 'orm_test_section',
            ),
            array(
                'type' => 'orm_test_ui',
                'id'   => 'orm_test_ui',
            ),
            array( 'type' => 'sectionend', 'id' => 'orm_test_section' ),
        ) );
    }

    // ── Custom field type renderer: channel checkboxes ────────────────────────

    /**
     * Render the multi-channel checkboxes (called via woocommerce_admin_field_ hook).
     */
    public static function render_channels_checkboxes() {
        $active   = (array) get_option( 'orm_channels', array( 'telegram' ) );
        $channels = array(
            'whatsapp' => __( '💬 WhatsApp', 'order-receipts-sender-for-woocommerce' ),
            'telegram' => __( '✈️ Telegram', 'order-receipts-sender-for-woocommerce' ),
            'sms'      => __( '📲 SMS', 'order-receipts-sender-for-woocommerce' ),
        );
        echo '<tr valign="top"><th scope="row" class="titledesc">' . esc_html__( 'Send receipts via', 'order-receipts-sender-for-woocommerce' ) . '</th><td class="forminp">';
        wp_nonce_field( 'orm_save_settings', 'orm_settings_nonce' );
        foreach ( $channels as $key => $label ) {
            $checked = in_array( $key, $active, true ) ? 'checked' : '';
            echo '<label style="display:block;margin-bottom:6px;">';
            echo '<input type="checkbox" name="orm_channels[]" value="' . esc_attr( $key ) . '" ' . esc_attr( $checked ) . ' style="margin-right:6px;">';
            echo esc_html( $label );
            echo '</label>';
        }
        echo '</td></tr>';
    }

    // ── Custom field type renderer: test UI ───────────────────────────────────

    /**
     * Render the per-channel test panel (called via woocommerce_admin_field_ hook).
     */
    public static function render_test_ui() {
        ?>
        <tr valign="top">
            <th scope="row" class="titledesc"><?php esc_html_e( 'Test', 'order-receipts-sender-for-woocommerce' ); ?></th>
            <td class="forminp">
                <table style="border-collapse:collapse;width:100%;">
                    <tr>
                        <td style="padding:4px 8px 4px 0;">
                            <select id="orm-test-channel" style="width:140px;">
                                <option value="whatsapp"><?php esc_html_e( 'WhatsApp', 'order-receipts-sender-for-woocommerce' ); ?></option>
                                <option value="telegram"><?php esc_html_e( 'Telegram', 'order-receipts-sender-for-woocommerce' ); ?></option>
                                <option value="sms"><?php esc_html_e( 'SMS', 'order-receipts-sender-for-woocommerce' ); ?></option>
                            </select>
                        </td>
                        <td style="padding:4px 8px 4px 0;">
                            <input type="text" id="orm-test-recipient" style="width:220px;"
                                   placeholder="<?php esc_attr_e( 'Phone or Chat ID', 'order-receipts-sender-for-woocommerce' ); ?>" />
                        </td>
                        <td style="padding:4px 0;">
                            <button type="button" id="orm-send-test" class="button button-secondary">
                                <?php esc_html_e( 'Send Test', 'order-receipts-sender-for-woocommerce' ); ?>
                            </button>
                        </td>
                    </tr>
                </table>
                <span id="orm-test-result" style="display:block;margin-top:6px;font-weight:600;"></span>
            </td>
        </tr>
        <?php
    }

    // ── Frontend OTP asset enqueue ────────────────────────────────────────────

    /**
     * Enqueue OTP JS on WooCommerce account/registration pages.
     */
    public static function enqueue_frontend_otp_assets() {
        if ( get_option( 'orm_otp_enabled', 'no' ) !== 'yes' ) return;
        if ( ! function_exists( 'is_account_page' ) ) return;
        if ( ! is_account_page() ) return;

        wp_enqueue_script(
            'orm-otp-login',
            ORM_PLUGIN_URL . 'assets/otp-login.js',
            array( 'jquery' ),
            ORM_VERSION,
            true
        );
        wp_localize_script( 'orm-otp-login', 'ormOtp', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'orm_otp_nonce' ),
        ) );
    }
}

// ── Wire up the static renderers via add_action (outside the class, but calling class methods) ──
add_action( 'woocommerce_admin_field_orm_channels_checkboxes', array( 'ORM_Settings', 'render_channels_checkboxes' ) );
add_action( 'woocommerce_admin_field_orm_test_ui',             array( 'ORM_Settings', 'render_test_ui' ) );
add_action( 'wp_enqueue_scripts',                              array( 'ORM_Settings', 'enqueue_frontend_otp_assets' ) );
